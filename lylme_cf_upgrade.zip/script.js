
const canvas = document.getElementById('bg');
const ctx = canvas.getContext('2d');

function resize(){
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resize();
window.addEventListener('resize', resize);

const stars = Array.from({length:120}, () => ({
  x: Math.random() * canvas.width,
  y: Math.random() * canvas.height,
  r: Math.random() * 2,
  s: Math.random() * 0.5 + 0.2
}));

function animate(){
  ctx.clearRect(0,0,canvas.width,canvas.height);

  stars.forEach(star=>{
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.r, 0, Math.PI*2);
    ctx.fillStyle = 'white';
    ctx.fill();

    star.y += star.s;
    if(star.y > canvas.height){
      star.y = 0;
      star.x = Math.random() * canvas.width;
    }
  });

  requestAnimationFrame(animate);
}
animate();

function updateTime(){
  const now = new Date();
  document.getElementById('time').innerText =
    now.toLocaleString('zh-CN', { hour12:false });

  const hour = now.getHours();
  let greeting = '欢迎回来';

  if(hour < 6) greeting = '夜深了';
  else if(hour < 12) greeting = '早上好';
  else if(hour < 18) greeting = '下午好';
  else greeting = '晚上好';

  document.getElementById('greeting').innerText = greeting;
}

updateTime();
setInterval(updateTime,1000);
