
# Cloudflare Pages 版

## 部署方式

1. 上传到 GitHub
2. 登录 Cloudflare Pages
3. Connect to Git
4. 选择仓库
5. Framework preset 选择 None
6. Build command 留空
7. Output directory 留空
8. Deploy

## 已升级内容

- Cloudflare Pages 适配
- 去 PHP 化
- 毛玻璃 UI
- 星空动态背景
- 响应式布局
- 动态时间
- GPT / GitHub 快捷入口
